INSTALL INSTRUCTIONS:

Run:
> python3 -m pip install dist/WalabotAPI-1.0.0.tar.gz
